export type WorkshopModule = {
  slug: string;
  title: string;
  summary: string;
};
