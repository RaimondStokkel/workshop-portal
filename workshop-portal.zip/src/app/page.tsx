import { WorkshopView } from "@/components/WorkshopView";

export default function Home() {
  return <WorkshopView />;
}
